//
//  CreateValidator.swift
//  GarmentEase
//
//  Created by Jing Yang on 2023-06-15.
//

import Foundation

struct CreateValidatorImpl {
    func validate(_ item: Item, provider: ItemsProvider) throws {
        if (item.name ?? "").isEmpty {
            throw CreateValidatorError.emptyName
        }
        
//        if let context = item.managedObjectContext {
        if provider.exists(item: item, in: provider.newContext) {
                throw CreateValidatorError.duplicateName
            }
//        }
    }
}

extension CreateValidatorImpl {
    enum CreateValidatorError: LocalizedError {
        case emptyName
        case duplicateName
        
        var failureReason: String? {
            switch self {
            case .emptyName:
                return NSLocalizedString("Empty Name", comment: "empty error title")
            case .duplicateName:
                return NSLocalizedString("Duplicate Name", comment: "duplicate error title")
            }
        }
        
        var errorDescription: String? {
            switch self {
            case .emptyName:
                return NSLocalizedString("Garment Name can't be empty", comment: "empty error description")
            case .duplicateName:
                return NSLocalizedString("Garment Name needs to be unique", comment: "duplicate error description")
            }
        }
    }
}
