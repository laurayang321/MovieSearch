//
//  EnvironmentValues+Extension.swift
//  GarmentEase
//
//  Created by Jing Yang on 2023-06-14.
//

import SwiftUI

extension EnvironmentValues {
    static var isPreview: Bool {
        return ProcessInfo.processInfo.environment["XCODE_RUNNING_FOR_PREVIEWS"] == "1"
    }
}
