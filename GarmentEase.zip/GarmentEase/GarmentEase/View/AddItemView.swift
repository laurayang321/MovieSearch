//
//  AddItemView.swift
//  GarmentEase
//
//  Created by Jing Yang on 2023-06-12.
//

import SwiftUI
import CoreData
import Foundation

struct AddItemView: View {
    // MARK: PROPERTIES
//    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) private var presentationMode
//    @State var name: String = ""
//    @State private var errorShowing: Bool = false
//    @State private var errorTitle: String = "Invalid Name"
//    @State private var errorMessage: String = "Make sure to enter something for\nthe new garment name."
    
    @State var error: CreateValidatorImpl.CreateValidatorError?
    
    @ObservedObject var vm: ItemViewModel
    @FocusState private var focusedField: Field? // TODO: if need?
    
    init(vm: ItemViewModel) {
        self.vm = vm
    }
    
    func create() {
        vm.item.timestamp = Date()
        vm.item.id = UUID()
        
        focusedField = nil
        do {
            try vm.save()
            if vm.state == .successful {
                self.presentationMode.wrappedValue.dismiss()
            }
        } catch {
            self.error = vm.error
            print(error)
        }
    }
    
    // MARK: BODY
    var body: some View {
        NavigationView {
            VStack {
                Form {
                    Text("Garment Name")
                    TextField("", text: $vm.item.name.toUnwrapped(defaultValue: ""))
                        .focused($focusedField, equals: .name)
                } //: FORM
                Spacer()
            } //: VSTACK
            .edgesIgnoringSafeArea(.bottom)
            .navigationTitle("ADD")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                Button("Save") {
//                    saveItem()
                    create()
                }
            }
            .alert(isPresented: $vm.hasError) {
                Alert(title: Text(error?.failureReason ?? "Error"), message: Text(error?.localizedDescription ?? "Try Again"), dismissButton: .default(Text("OK")))
          }
        } //: NAVIGATION
        
    }
    
//    func saveItem() {
//        withAnimation {
//            if self.name != "" {
//                let newItem = Item(context: viewContext)
//                newItem.id = UUID()
//                newItem.name = self.name
//                newItem.timestamp = Date()
//                do {
//                    try viewContext.save()
//                    print("New Garment: \(name), created at \(itemFormatter.string(from: newItem.timestamp!))")
//                } catch {
//                    print(error)
//                }
//            } else {
//                self.errorShowing = true
//
//            }
//            self.presentationMode.wrappedValue.dismiss()
//        }
//    }
}

// MARK: PREVIEW
struct AddItemView_Previews: PreviewProvider {
    static var previews: some View {
        
        let preview = ItemsProvider.shared
        NavigationStack {
            AddItemView(vm: .init(provider: preview))
                .environment(\.managedObjectContext, preview.viewContext)
        }
    }
}

extension Binding {
     func toUnwrapped<T>(defaultValue: T) -> Binding<T> where Value == Optional<T>  {
        Binding<T>(get: { self.wrappedValue ?? defaultValue }, set: { self.wrappedValue = $0 })
    }
}

extension AddItemView {
    enum Field: Hashable {
        case name
        case id
        case timestamp
    }
}
