//
//  ContentView.swift
//  GarmentEase
//
//  Created by Jing Yang on 2023-06-12.
//

import SwiftUI
import CoreData

struct ContentView: View {
    // MARK: PROPERTIES
//    @Environment(\.managedObjectContext) private var viewContext
    @State var showAddItemView = false
    @State var sortDescriptor: NSSortDescriptor = NSSortDescriptor(keyPath: \Item.name, ascending: true)
    @State private var sortType: Int = 0
    let provider = ItemsProvider.shared

    // MARK: BODY
    var body: some View {
        NavigationView {
            VStack {
                // Sorting Picker
                Picker(selection: $sortType, label: Text("Sort")) {
                    Text("Alpha").tag(0)
                    Text("Creation Time").tag(1)
                }
                .pickerStyle(SegmentedPickerStyle())
                .onChange(of: sortType) { value in
                    sortType = value
                    if sortType == 0 {
                        sortDescriptor = NSSortDescriptor(keyPath: \Item.name, ascending: true)
                    } else {
                        sortDescriptor = NSSortDescriptor(keyPath: \Item.timestamp, ascending: true)
                    }
                }
                
                // List
                ListView(sortDescriptor, provider)
                .toolbar {
                    ToolbarItem {
                        Button(action: {
                            self.showAddItemView.toggle()
                            // sqlite db path
                            print(FileManager.default.urls(for: .documentDirectory, in: .userDomainMask))
                        }) {
                            Label("Add Item", systemImage: "plus")
                        }
                        .sheet(isPresented: $showAddItemView) {
                            AddItemView(vm: .init(provider: provider))
                        }
                    }
                }
                .navigationTitle("LIST")
                .navigationBarTitleDisplayMode(.inline)
            } //: VSTACK
        } //: NAVIGATION
    }
}

struct ListView: View {
    @FetchRequest var items: FetchedResults<Item>
//    @Environment(\.managedObjectContext) var viewContext
    @ObservedObject var provider: ItemsProvider
    
    init(_ sortDescriptor: NSSortDescriptor, _ provider: ItemsProvider) {
        let request: NSFetchRequest<Item> = Item.fetchRequest()
        request.sortDescriptors = [sortDescriptor]
        _items = FetchRequest<Item>(fetchRequest: request)
        self.provider = provider
    }
    
    var body: some View {
        List {
            ForEach(items, id: \.self) { item in
                NavigationLink {
                    Text("Item at \(item.timestamp ?? Date()), formatter: itemFormatter)")
                } label: {
                    HStack{
                        Text(item.name ?? "Pants")
                        Spacer()
                        Text(item.timestamp ?? Date(), formatter: itemFormatter)
                    }
                }
            }
            .onDelete(perform: deleteItems)
        }
    }
    
    func deleteItems(offsets: IndexSet) {
        withAnimation {
            offsets.map { items[$0] }.forEach { item in
                do {
                    try provider.delete(item)
                } catch {
                    print(error)
                }
            }
            
//            do {
//                try viewContext.save()
//            } catch {
//                // Replace this implementation with code to handle the error appropriately.
//                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
//                let nsError = error as NSError
//                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
//            }
        }
    }
}

let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .short
    return formatter
}()

// MARK: PREVIEW
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        let previewProvider = ItemsProvider.shared
        
        ContentView().environment(\.managedObjectContext, previewProvider.viewContext)
    }
}
