//
//  ItemsProvider.swift
//  GarmentEase
//
//  Created by Jing Yang on 2023-06-14.
//

import Foundation
import CoreData
import SwiftUI

final class ItemsProvider: ObservableObject {
    
    static var shared = ItemsProvider()
    private let persistentContainer: NSPersistentContainer
    
    var viewContext: NSManagedObjectContext {
        persistentContainer.viewContext
    }
    
    var newContext: NSManagedObjectContext {
        persistentContainer.newBackgroundContext()
    }
    
    public func getItems() -> [Item]? {
      let itemsFetch: NSFetchRequest<Item> = Item.all()
      do {
        let results = try viewContext.fetch(itemsFetch)
        return results
      } catch let error as NSError {
        print("Fetch error: \(error) description: \(error.userInfo)")
      }
      return nil
    }
    
    private init () {
        persistentContainer = NSPersistentContainer(name: "GarmentEase")
        if EnvironmentValues.isPreview || Thread.current.isRunningXCTest {
            persistentContainer.persistentStoreDescriptions.first?.url = .init(fileURLWithPath: "/dev/null")
        }
        persistentContainer.viewContext.automaticallyMergesChangesFromParent = true
        persistentContainer.loadPersistentStores { _, error in
            if let error {
                fatalError("Unable to load store with \(error)")
            }
        }
    }
    
    func exists(item: Item, in context: NSManagedObjectContext) -> Bool {
//        try? context.existingObject(with: item.objectID) as? Item
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Item")
        fetchRequest.fetchLimit =  1
        fetchRequest.predicate = NSPredicate(format: "name == %@" ,item.name ?? "")

        do {
            let count = try newContext.count(for: fetchRequest)
            if count > 0 {
                return true
            }else {
                return false
            }
        }catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return false
        }
    }
    
    func persists(in context: NSManagedObjectContext) throws {
        if context.hasChanges {
            try context.save()
        }
    }
    
    func delete(_ item: Item) {
        guard let context = item.managedObjectContext else { return }

        context.delete(item)
    
        do {
            try persists(in: viewContext)
        } catch {
            print("An error occurred while saving: \(error)")
        }

//        if context == self.viewContext {
//            context.delete(item)
//            try? self.viewContext.save()
//            return true
//        } else {
//            Task(priority: .background) {
//                await context.perform {
//                    context.delete(item)
//                    try? self.viewContext.save()
//                    return true
//                }
//            }
//        }
//
//        return false
//        if exists(item: item, in: newContext) {
//            viewContext.delete(item)
//            Task(priority: .background) {
//                try await viewContext.perform {
//                    try self.viewContext.save()
//                    return true
//                }
//            }
//        }
//        return false
    }
}


