//
//  Item.swift
//  GarmentEase
//
//  Created by Jing Yang on 2023-06-15.
//

import Foundation
import CoreData

extension Item {
    
    static func empty(context: NSManagedObjectContext = ItemsProvider.shared.viewContext) -> Item {
        return Item(context: context)
    }
    
    private static var itemsFetchRequest: NSFetchRequest<Item> {
        NSFetchRequest(entityName: "Item")
    }
    
    static func all() -> NSFetchRequest<Item> {
        let request: NSFetchRequest = itemsFetchRequest
        
        request.sortDescriptors = [
            NSSortDescriptor(keyPath: \Item.name, ascending: true)
        ]
        
        return request
    }
}
