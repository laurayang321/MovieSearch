//
//  ItemViewModel.swift
//  GarmentEase
//
//  Created by Jing Yang on 2023-06-14.
//

import Foundation
import CoreData

final class ItemViewModel: ObservableObject {
    
    @Published var item: Item
    @Published var hasError = false
    @Published var error: CreateValidatorImpl.CreateValidatorError?
    @Published private(set) var state: SubmissionState?
    
    let isNew: Bool
    private let provider: ItemsProvider
    private let context: NSManagedObjectContext
    
    private let validator: CreateValidatorImpl
    
    init(provider: ItemsProvider,
         item: Item? = nil,
         validator: CreateValidatorImpl = CreateValidatorImpl()
    ) {
        self.validator = validator
        self.provider = provider
        self.context = provider.newContext
        if let item, provider.exists(item: item, in: context) {
            self.item = item
            self.isNew = false
        } else {
            self.item = Item(context: context)
            self.isNew = true
            self.error = error
        }
    }
    
    func save() throws {
        do {
            try validator.validate(item, provider: provider)
            state = .submitting
            try provider.persists(in: context)
            state = .successful
        } catch {
            self.hasError = true
            self.state = .unsuccessful
            self.error = error as? CreateValidatorImpl.CreateValidatorError
            throw error
        }
    }
    
}

extension ItemViewModel {
    enum SubmissionState {
        case unsuccessful
        case successful
        case submitting
    }
}

