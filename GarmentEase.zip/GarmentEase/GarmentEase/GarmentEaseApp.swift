//
//  GarmentEaseApp.swift
//  GarmentEase
//
//  Created by Jing Yang on 2023-06-12.
//

import SwiftUI

@main
struct GarmentEaseApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, ItemsProvider.shared.viewContext)
        }
    }
}
