//
//  GarmentEaseTests.swift
//  GarmentEaseTests
//
//  Created by Jing Yang on 2023-06-12.
//

import XCTest
@testable import GarmentEase
import CoreData
import SwiftUI

class GarmentEaseTests: XCTestCase {

    private var provider: ItemsProvider!
    private var validator: CreateValidatorImpl!
    
    override func setUp() {
        super.setUp()
        provider = .shared
        validator = CreateValidatorImpl()
    }
    
    override func tearDown() {
        super.tearDown()
        validator = nil
        provider = nil
    }

    func testItemIsEmpty () {
        let item: Item = Item.empty(context: provider.viewContext)
        
        XCTAssertEqual(item.name, nil)
    }

    func testAddItem() {
        let vm = ItemViewModel.init(provider: provider)
        let addItemView = AddItemView(vm: vm)
        vm.item.name = "Cup"
        addItemView.create()
        XCTAssertNotNil(vm.item)
    }
    
    func testDeleteItem() async {
        let vm = ItemViewModel.init(provider: provider)
        let addItemView = await AddItemView(vm: vm)
        vm.item.name = "Hoodies"
        await addItemView.create()
        XCTAssertNotNil(vm.item)
        
        let items = provider.getItems() ?? []
        for item in items {
            provider.delete(item)
        }
        XCTAssertEqual(0, provider.getItems()?.count)
    }

    func testValidateDuploicateName() {
        let vm = ItemViewModel.init(provider: provider)
        let addItemView = AddItemView(vm: vm)
        
        vm.item.name = "Hoodies"
        addItemView.create()
        
        vm.item.name = "Hoodies"
        vm.item.timestamp = Date()
        vm.item.id = UUID()
        
        do {
            _ = try vm.save()
            
        } catch {
            guard let validatorError = error as? CreateValidatorImpl.CreateValidatorError else {
                XCTFail("Got the wrong type of error, expecting a create validator error")
                return
            }
            
            XCTAssertEqual(validatorError, CreateValidatorImpl.CreateValidatorError.duplicateName, "Expecting an error where we have an invalid name")
        }
    }
    
    func testValidateEmptyName() {
        let item = Item.empty(context: provider.viewContext)
        
        XCTAssertThrowsError(try validator.validate(item, provider: provider), "Error for an empty name should be thrown")
        
        do {
            _ = try validator.validate(item, provider: provider)
            
        } catch {
            guard let validatorError = error as? CreateValidatorImpl.CreateValidatorError else {
                XCTFail("Got the wrong type of error, expecting a create validator error")
                return
            }
            
            XCTAssertEqual(validatorError, CreateValidatorImpl.CreateValidatorError.emptyName, "Expecting an error where we have an invalid name")
        }
    }
    
}
